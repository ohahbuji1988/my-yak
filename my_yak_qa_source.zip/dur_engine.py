from typing import List, Dict, Any

# DUR (Drug Utilization Review) 병용금기/성인·소아·임부 주의 룰 데이터
DUR_INTERACTION_RULES = [
    {
        "drugs": ["맥시부펜시럽", "타이레놀8시간이알서방정"],
        "type": "성분중복/해열제중복",
        "severity": "WARNING",
        "message": "해열진통제(덱시부프로펜 + 아세트아미노펜) 동시 복용 시 교차복용 시간 간격(최소 2시간)을 준수해야 합니다."
    },
    {
        "drugs": ["코싹엘정", "코미시럽"],
        "type": "항히스타민 중복",
        "severity": "CAUTION",
        "message": "항히스타민 성분이 중복 포함되어 있어 심한 졸음이나 입마름이 유발될 수 있습니다."
    }
]

def check_dur_interactions(analyzed_drugs: List[Dict[str, Any]], is_pregnant: bool = False) -> List[Dict[str, Any]]:
    """
    DUR (Drug Utilization Review) 병용금기 및 중복 복약 검증
    """
    warnings = []
    matched_names = [d.get("drug_name", "") for d in analyzed_drugs if d.get("drug_name")]

    # 1. 약품 간 병용금기/중복 검증
    for rule in DUR_INTERACTION_RULES:
        rule_drugs = rule["drugs"]
        if all(any(rd in name for name in matched_names) for rd in rule_drugs):
            warnings.append({
                "type": rule["type"],
                "severity": rule["severity"],
                "message": rule["message"],
                "affected_drugs": rule_drugs
            })

    # 2. 임부 주의/금기 검증
    if is_pregnant:
        for drug in analyzed_drugs:
            name = drug.get("drug_name", "")
            if "맥시부펜" in name or "덱시부프로펜" in name or "아세트아미노펜" in name:
                warnings.append({
                    "type": "임부주의",
                    "severity": "WARNING",
                    "message": f"'{name}'은 임신 중 복용 시 의사·약사와 상담이 필요합니다.",
                    "affected_drugs": [name]
                })

    return warnings
