from typing import List, Dict, Any

LEGAL_DISCLAIMER_TEXT = (
    "※ 본 서비스는 공공 의약품 데이터 기반의 참고 자료일 뿐, "
    "의사·약사의 의학적 소견을 대체하지 않습니다. "
    "복약 관련 결정은 반드시 의료진과 상의하세요."
)

def generate_safety_report(profile: Dict[str, Any], analyzed_drugs: List[Dict[str, Any]]) -> str:
    """
    Stage 2 LLM 안심 리포트 생성기 (객관적/안심 표현 가드레일 준수)
    - 공포 유발 금지, 100% 보장 표현 금지, 식약처 공공 데이터 근거 기반 설명
    """
    user_name = profile.get("name", "환자")
    member_type = profile.get("member_type", "ADULT")
    weight_kg = profile.get("weight_kg")
    
    is_child = member_type.upper() == "CHILD"
    profile_str = f"{user_name} 님 ({'소아' if is_child else '성인'}"
    if is_child and weight_kg:
        profile_str += f", {weight_kg}kg"
    profile_str += ")"

    lines = []
    lines.append(f"📋 **[My 약] 온 가족 복약 안심 분석 리포트**")
    lines.append(f"대상: **{profile_str}**\n")
    lines.append("---")
    lines.append("### 💊 처방 의약품 복약 적정성 분석\n")

    has_warning = False
    has_unknown = False

    for idx, drug in enumerate(analyzed_drugs, 1):
        original = drug.get("original_scanned", "")
        matched = drug.get("drug_name", original)
        status = drug.get("status", "SAFE")
        comment = drug.get("comment", "")
        safety_guide = drug.get("safety_guide", "")
        candidates = drug.get("candidates", [])

        # 상태별 아이콘 및 설명
        if status == "SAFE":
            icon = "✅ [안심 범위]"
        elif status == "WARNING":
            icon = "⚠️ [용량 주의]"
            has_warning = True
        elif status in ("HIGH", "LOW"):
            icon = "ℹ️ [권장 범위 참조]"
        else: # UNKNOWN / CAUTION
            icon = "❓ [확인 불가(모름)]"
            has_unknown = True

        lines.append(f"**{idx}. {matched}** (인식명: `{original}`)")
        lines.append(f"- 상태: {icon}")
        lines.append(f"- 안내: {comment}")
        if safety_guide:
            lines.append(f"- 복약가이드: {safety_guide}")
        
        if status == "UNKNOWN" and candidates:
            lines.append(f"- 💡 혹시 다음 약품 중 하나인가요? `{', '.join(candidates[:3])}`")
        lines.append("")

    lines.append("---")
    lines.append("### 💡 복약 지도 핵심 종합 조언")
    
    if is_child:
        lines.append("1. **시럽제 용량 측정**: 전용 계량 스푼 또는 주사기를 사용하여 정량을 투여해 주세요.")
        lines.append("2. **해열제 복용 간격**: 해열제 복용 시 최소 4~6시간 간격을 준수해 주세요.")
    else:
        lines.append("1. **복약 시간 준수**: 처방전 및 약봉투에 기재된 일일 복용 횟수와 간격을 지켜주세요.")
        lines.append("2. **주요 부작용 주의**: 졸음이 유발될 수 있는 경우 운전이나 위험한 기계 조작을 피하세요.")

    if has_warning:
        lines.append("3. ⚠️ **주의사항**: 일일 권장 용량을 초과하거나 주의가 필요한 약품이 포함되어 있으므로 약사 또는 의사와 확인 후 복용하세요.")
    if has_unknown:
        lines.append("4. ❓ **확인 불가 안내**: 시스템에서 정밀 매칭되지 않은 약품은 조제 약봉투의 안내 문구를 필히 확인해 주세요.")

    lines.append("\n" + LEGAL_DISCLAIMER_TEXT)
    return "\n".join(lines)

async def generate_safety_report_async(profile: Dict[str, Any], analyzed_drugs: List[Dict[str, Any]]) -> str:
    """Gemini API가 설정된 경우 실시간 LLM 가이드 생성, 미설정 또는 실패 시 룰베이스 Fallback"""
    import os
    if os.getenv("GEMINI_API_KEY"):
        try:
            from gemini_service import call_gemini_generate
            prompt = (
                f"환자 프로필: {profile}\n"
                f"처방 분석 결과: {analyzed_drugs}\n"
                "위 정보를 바탕으로 보호자를 위해 다정하고 명확한 4~5줄의 복약 안심 안내 요약을 작성해 주세요. "
                "공포심이나 100% 안전 보장은 배제하고 객관적인 사실과 주의점 위주로 작성하세요."
            )
            res = await call_gemini_generate(
                prompt=prompt,
                system_instruction="당신은 식약처 공공데이터에 근거하여 처방전을 안심 검증해 주는 소아과/약학 전문 비서 AI입니다."
            )
            if res.get("success") and res.get("text"):
                base_report = generate_safety_report(profile, analyzed_drugs)
                return f"{base_report}\n\n🤖 **[AI 안심 어드바이저 소견]**\n{res['text']}"
        except Exception:
            pass

    return generate_safety_report(profile, analyzed_drugs)

