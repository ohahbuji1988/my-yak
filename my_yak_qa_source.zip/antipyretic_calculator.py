from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

# 해열제 계열 정의
# 계열 1: 아세트아미노펜 (타이레놀, 챔프 빨강 등)
# 계열 2: 이부프로펜 / 덱시부프로펜 (맥시부펜, 챔프 파랑 등)
ANTIPYRETIC_CLASSES = {
    "ACETAMINOPHEN": {
        "name": "아세트아미노펜 계열",
        "keywords": ["타이레놀", "아세트아미노펜", "세토펜", "챔프빨강", "콜대원보라"],
        "min_interval_hours": 4.0,
        "single_dose_mg_kg": 12.5, # 10~15 mg/kg
        "daily_limit_mg_kg": 75.0,
        "concentration_mg_ml": 32.0 # 어린이타이레놀현탁액 (32mg/ml)
    },
    "DEXIBUPROFEN": {
        "name": "덱시부프로펜/이부프로펜 계열",
        "keywords": ["맥시부펜", "덱시부프로펜", "이부프로펜", "부루펜", "챔프파랑", "콜대원주황"],
        "min_interval_hours": 4.0,
        "single_dose_mg_kg": 6.0, # 5~7 mg/kg
        "daily_limit_mg_kg": 28.0,
        "concentration_mg_ml": 12.0 # 맥시부펜시럽 (12mg/ml)
    }
}

CROSS_DOSE_MIN_INTERVAL_HOURS = 2.0  # 교차복용(다른 계열) 최소 권장 간격: 2시간

def identify_antipyretic_class(drug_name: str) -> Optional[str]:
    """약품명에서 해열제 계열 식별"""
    cleaned = drug_name.replace(" ", "")
    for cls_key, info in ANTIPYRETIC_CLASSES.items():
        if any(k in cleaned for k in info["keywords"]):
            return cls_key
    return None

def calculate_antipyretic_dosage(weight_kg: float, antipyretic_class: str) -> Dict[str, Any]:
    """체중(kg) 기준 1회 적정 권장 복용량(ml 및 mg) 계산"""
    cls_info = ANTIPYRETIC_CLASSES.get(antipyretic_class)
    if not cls_info:
        return {}

    single_mg = weight_kg * cls_info["single_dose_mg_kg"]
    single_ml = round(single_mg / cls_info["concentration_mg_ml"], 1)
    daily_limit_mg = weight_kg * cls_info["daily_limit_mg_kg"]
    daily_limit_ml = round(daily_limit_mg / cls_info["concentration_mg_ml"], 1)

    return {
        "class_name": cls_info["name"],
        "weight_kg": weight_kg,
        "single_dose_mg": round(single_mg, 1),
        "single_dose_ml": single_ml,
        "daily_limit_mg": round(daily_limit_mg, 1),
        "daily_limit_ml": daily_limit_ml,
        "min_same_interval_hours": cls_info["min_interval_hours"]
    }

def calculate_next_dose_timing(
    weight_kg: float,
    last_drug_name: str,
    last_dose_time: datetime,
    target_next_drug_name: Optional[str] = None
) -> Dict[str, Any]:
    """
    마지막 복용 약품과 복용 시간을 기준으로
    동일 계열 복용 가능 시각 및 다른 계열 교차복용 가능 시각 계산
    """
    last_class = identify_antipyretic_class(last_drug_name)
    
    # 1. 동일 계열 다음 복용 가능 시각 (최소 4시간 후)
    same_class_time = last_dose_time + timedelta(hours=4)
    # 2. 교차 복용(다른 계열) 다음 복용 가능 시각 (최소 2시간 후)
    cross_class_time = last_dose_time + timedelta(hours=CROSS_DOSE_MIN_INTERVAL_HOURS)

    alt_class = "DEXIBUPROFEN" if last_class == "ACETAMINOPHEN" else "ACETAMINOPHEN"
    last_dosage_info = calculate_antipyretic_dosage(weight_kg, last_class) if last_class else {}
    alt_dosage_info = calculate_antipyretic_dosage(weight_kg, alt_class)

    return {
        "weight_kg": weight_kg,
        "last_drug": {
            "name": last_drug_name,
            "class": last_class or "UNKNOWN",
            "dose_time": last_dose_time.strftime("%H:%M"),
            "dosage_guide": last_dosage_info
        },
        "timings": {
            "cross_dose_earliest_time": cross_class_time.strftime("%H:%M"),
            "cross_dose_min_interval_hours": CROSS_DOSE_MIN_INTERVAL_HOURS,
            "same_dose_earliest_time": same_class_time.strftime("%H:%M"),
            "same_dose_min_interval_hours": 4.0
        },
        "cross_dose_recommendation": {
            "recommended_alt_class": ANTIPYRETIC_CLASSES[alt_class]["name"],
            "alt_single_dose_ml": alt_dosage_info.get("single_dose_ml", 0.0),
            "safety_note": f"2시간 경과 후에도 38도 이상 고열 지속 시 {ANTIPYRETIC_CLASSES[alt_class]['name']} ({alt_dosage_info.get('single_dose_ml', 0.0)}ml)을 교차 투여하세요."
        }
    }
