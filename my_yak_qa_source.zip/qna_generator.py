from typing import List, Dict, Any

def generate_doctor_qna(
    profile: Dict[str, Any],
    analyzed_drugs: List[Dict[str, Any]],
    allergy_notes: str = ""
) -> List[Dict[str, Any]]:
    """
    처방 약품 목록 및 아이 프로필 정보를 바탕으로
    소아과 방문 시 의사에게 문의할 추천 질문지(Q&A)를 자동 생성합니다.
    """
    child_name = profile.get("name", "아기")
    weight_kg = profile.get("weight_kg")
    
    questions: List[Dict[str, Any]] = []
    drug_names = [d.get("drug_name", "") for d in analyzed_drugs]
    combined_names = " ".join(drug_names)

    # 1. 항히스타민제 / 비염약 관련 질문 (졸림, 대체약 문의)
    if any(k in combined_names for k in ["코미시럽", "코싹", "항히스타민", "페닐레프린"]):
        questions.append({
            "id": "q_antihistamine_drowsy",
            "category": "부작용/대체약",
            "question": f"{drug_names[0] if drug_names else '감기 물약'} 복용 후 졸림이나 입마름 증상이 심해지면, 다음 방문 시 다른 성분의 대체약으로 변경 처방이 가능한가요?",
            "is_default_selected": True
        })

    # 2. 항생제 관련 질문 (설사, 유산균 복용)
    if any(k in combined_names for k in ["아모클란", "아모크라", "항생제", "클라불란산", "세파"]):
        questions.append({
            "id": "q_antibiotic_diarrhea",
            "category": "항생제/소화기",
            "question": "항생제 복용 중 설사나 무른변 증상이 생길 수 있다고 들었는데, 비오플 등 정장제(유산균)를 몇 시간 간격을 두고 함께 먹여야 하나요?",
            "is_default_selected": True
        })

    # 3. 해열진통제 관련 질문 (교차복용 간격)
    if any(k in combined_names for k in ["맥시부펜", "타이레놀", "아세트아미노펜", "이부프로펜", "덱시부프로펜"]):
        questions.append({
            "id": "q_antipyretic_cross",
            "category": "해열제 교차복용",
            "question": f"현재 처방약과 다른 계열의 상비 해열제(아세트아미노펜/이부프로펜)를 열이 안 떨어질 때 몇 시간 간격으로 교차 복용시켜야 안전한가요?",
            "is_default_selected": True
        })

    # 4. 알레르기 이력 특이사항 관련 질문
    if allergy_notes or "페니실린" in allergy_notes:
        questions.append({
            "id": "q_allergy_alert",
            "category": "알레르기 주의",
            "question": f"{child_name}에게 기존 알레르기/발진 이력({allergy_notes or '항생제 발진'})이 있는데, 이번 처방약 중 교차 반응 위험이 있는 성분이 포함되어 있나요?",
            "is_default_selected": True
        })

    # 5. 복용 시간 누락 대처 질문 (기본 상시 질문)
    questions.append({
        "id": "q_missed_dose",
        "category": "용법/시간 누락",
        "question": f"깜빡 잊고 {child_name}의 약 복용 시간을 놓쳤을 때는 발견 즉시 바로 먹여야 하나요, 아니면 다음 복용 시간까지 건너뛰어야 하나요?",
        "is_default_selected": False
    })

    # 6. 체중 대비 정밀 증량 질문
    if weight_kg:
        questions.append({
            "id": "q_weight_dosage",
            "category": "체중 대비 용량",
            "question": f"현재 몸무게 {weight_kg}kg 기준 처방인데, 며칠 내 증상이 호전되지 않거나 체중 변화가 있을 때 용량을 조절해야 하나요?",
            "is_default_selected": False
        })

    return questions
