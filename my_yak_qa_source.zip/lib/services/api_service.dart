import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http/http.dart' as http;

import '../models/profile.dart';
import '../models/prescription.dart';

class ApiService {
  // Dynamic host determination: 127.0.0.1 for Web/Windows/iOS, 10.0.2.2 for Android emulator
  static String get baseUrl {
    if (kIsWeb) {
      return 'http://127.0.0.1:8000/api/v1';
    }
    try {
      if (Platform.isAndroid) {
        return 'http://10.0.2.2:8000/api/v1';
      }
    } catch (_) {}
    return 'http://127.0.0.1:8000/api/v1';
  }

  static Future<PrescriptionAnalysisResponse> analyzePrescription({
    required MemberProfile profile,
    required List<ScannedDrugItem> scannedDrugs,
  }) async {
    final url = Uri.parse('$baseUrl/prescriptions/analyze');

    final payload = {
      'profile': profile.toJson(),
      'scanned_drugs': scannedDrugs.map((d) => d.toJson()).toList(),
    };

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json; charset=UTF-8'},
      body: jsonEncode(payload),
    );

    if (response.statusCode == 200) {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      return PrescriptionAnalysisResponse.fromJson(decoded);
    } else {
      throw Exception('처방전 분석 실패 (${response.statusCode}): ${response.body}');
    }
  }

  static Future<PrescriptionAnalysisResponse> analyzePrescriptionImage({
    required MemberProfile profile,
    required String imageBase64,
    String mimeType = 'image/jpeg',
  }) async {
    final url = Uri.parse('$baseUrl/prescriptions/analyze-image');

    final payload = {
      'profile': profile.toJson(),
      'image_base64': imageBase64,
      'mime_type': mimeType,
    };

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json; charset=UTF-8'},
      body: jsonEncode(payload),
    );

    if (response.statusCode == 200) {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      return PrescriptionAnalysisResponse.fromJson(decoded);
    } else {
      throw Exception('이미지 처방전 분석 실패 (${response.statusCode}): ${response.body}');
    }
  }

  static Future<AiDeduction?> deduceDrugWithAi(String scannedName) async {
    try {
      final url = Uri.parse('$baseUrl/drugs/ai-deduce');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json; charset=UTF-8'},
        body: jsonEncode({'scanned_name': scannedName}),
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        return AiDeduction.fromJson(decoded);
      }
    } catch (_) {}
    return null;
  }
}
